package com.example.ict2_02_exam;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.homelist,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
       int id = item.getItemId();

       if (id == R.id.insert){
           Intent i = new Intent(MainActivity.this,InsertEmployee.class);
           startActivity(i);
       }else if (id == R.id.show){
           Intent i = new Intent(MainActivity.this,ShowEmployee.class);
           startActivity(i);
       }else{
           Intent i = new Intent(MainActivity.this,SearchEmployee.class);
           startActivity(i);
       }
        return super.onOptionsItemSelected(item);
    }
}