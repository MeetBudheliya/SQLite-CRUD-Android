package com.example.ict2_02_exam;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class InsertEmployee extends AppCompatActivity {

    EditText name, phone, email;
    Button insertBTN;
    AutoCompleteTextView designation;
    DBHelper DB;
    String[] designationList = {"Manager", "Executive", "Clerk", "Chief- Executive","Senior-Clerk"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_employee);
        DB = new DBHelper(this,"Employee",null,1);

        name = findViewById(R.id.emp_name_et);
        designation = findViewById(R.id.emp_designation_et);
        phone = findViewById(R.id.emp_phone_et);
        email = findViewById(R.id.emp_email_et);
        insertBTN = findViewById(R.id.Insert_button);
        designation = findViewById(R.id.emp_designation_et);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.select_dialog_item,designationList);
        designation.setThreshold(3);
        designation.setAdapter(adapter);

        insertBTN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (name.getText().toString() == ""){
                    Toast.makeText(InsertEmployee.this, "Please enter name", Toast.LENGTH_SHORT).show();
                }else if (designation.getText().toString() == ""){
                    Toast.makeText(InsertEmployee.this, "Please enter designation", Toast.LENGTH_SHORT).show();
                }else if (phone.getText().toString() == ""){
                    Toast.makeText(InsertEmployee.this, "Please enter phone", Toast.LENGTH_SHORT).show();
                }else if (email.getText().toString() == ""){
                    Toast.makeText(InsertEmployee.this, "Please enter email", Toast.LENGTH_SHORT).show();
                }else{
                    DB.addEmployee(name.getText().toString(),designation.getText().toString(),phone.getText().toString(),email.getText().toString());
                    Toast.makeText(InsertEmployee.this, "Record inserted successfully", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(InsertEmployee.this,ShowEmployee.class);
                    startActivity(i);
                }
            }
        });

    }
}