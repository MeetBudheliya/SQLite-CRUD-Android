package com.example.ict2_02_exam;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SearchEmployee extends AppCompatActivity {

    EditText serachBox;
    Button search_btn;
    DBHelper DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_employee);
        serachBox = findViewById(R.id.search_ET);
        search_btn = findViewById(R.id.search_btn);
        DB = new DBHelper(this,"Employee",null,1);

        search_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (serachBox.getText().toString() != ""){
                    StringBuffer buffer = new StringBuffer();
                    AlertDialog.Builder builder = new AlertDialog.Builder(SearchEmployee.this);
                    Cursor cursor = DB.GetEmployeeByName(serachBox.getText().toString());
                    while (cursor.moveToNext()){
                        buffer.append("emp_id : " + cursor.getString(0) + "'\n");
                        buffer.append("emp_name : " + cursor.getString(1) + "'\n");
                        buffer.append("emp_designation : " + cursor.getString(2) + "'\n");
                        buffer.append("emp_phone : " + cursor.getString(3) + "'\n");
                        buffer.append("emp_email : " + cursor.getString(4) + "'\n");
                        buffer.append("\n");
                    }
                    builder.setCancelable(true);
                    builder.setTitle("Employee Records");
                    builder.setMessage(buffer.toString());
                    builder.show();
                }
            }
        });

    }
}